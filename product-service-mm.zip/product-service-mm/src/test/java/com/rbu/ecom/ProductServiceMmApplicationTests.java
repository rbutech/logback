package com.rbu.ecom;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.rbu.ecom.model.Products;
import com.rbu.ecom.repo.ProductRepo;
import com.rbu.ecom.service.ProductService;

@SpringBootTest
public class ProductServiceMmApplicationTests {
	@Mock
	ProductRepo productRepo;
	@InjectMocks
	ProductService productService;
	@Test
	void createProductTest() {
		Products p=new Products();
		p.setProductName("IPHONE");
		Mockito.when(productRepo.save(Mockito.any(Products.class))).thenReturn(p);
		Optional<Products> products=productService.createProduct(p);
		assertEquals(products.get().getProductName(), p.getProductName());
	}
	@Test
	void updateProductTest() {
		Products p=new Products();
		p.setProductName("IPHONE");
		p.setProductId(1l);
		Mockito.when(productRepo.findById(Mockito.any(Long.class))).thenReturn(Optional.of(p));
		Mockito.when(productRepo.save(Mockito.any(Products.class))).thenReturn(p);
		Optional<Products> products=productService.updateProduct(p);
		assertEquals(products.get().getProductName(), p.getProductName());
	}

	@Test()
	//@Test(expected=MyException.class)
	void updateProductExceptionTest() {
		Products p=new Products();
		p.setProductName("IPHONE");
		p.setProductId(1l);
		//Mockito.when(productRepo.findById(Mockito.any(Long.class))).thenReturn(Optional.of());
		productService.updateProduct(p);
		assertEquals(1, 1);
	}

}
