package com.rbu.ecom.exception;

import java.time.LocalDate;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.rbu.ecom.service.ProductNotFoundException;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
	@ExceptionHandler(value = ProductNotFoundException.class)
	public ResponseEntity<ExceptionMessage> handleProductNotFound(Exception e){
		ExceptionMessage message=new ExceptionMessage();
		message.setMessage("Requested product Not available please check and try again");
		message.setCurrentTime(LocalDate.now());
		log.error("Exception occured {}",e);
		return new ResponseEntity<ExceptionMessage>(message, HttpStatus.BAD_REQUEST);
	}
	

}
