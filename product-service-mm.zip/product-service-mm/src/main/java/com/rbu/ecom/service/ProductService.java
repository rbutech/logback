package com.rbu.ecom.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.rbu.ecom.model.Products;
import com.rbu.ecom.repo.ProductRepo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class ProductService implements IProductService {
	public static final String PRODUCT_IS_NOT_AVAILABLE = "product is not available";
	final ProductRepo productRepo;

	@Override
	public Optional<Products> createProduct(Products product) {
		log.info("createProduct...{}",product);
		System.out.println("A");
		System.out.println("B");
		System.out.println("C");
		return Optional.of(productRepo.save(product));
	}

	@Override
	public Optional<Products> updateProduct(Products product) {
		Optional<Products> products = productRepo.findById(product.getProductId());
		log.info("updateProduct...{}",product);
		System.out.println("A");
		System.out.println("B");
		System.out.println("C");
		if (products.isPresent())
			return Optional.of(productRepo.save(product));
		throw new ProductNotFoundException(PRODUCT_IS_NOT_AVAILABLE);
	}

	@Override
	public void deleteProduct(Long id) {
		Optional<Products> products = productRepo.findById(id);
		log.info("deleteProduct...{}",id);
		System.out.println("A");
		System.out.println("B");
		System.out.println("C");
		products.ifPresent(productRepo::delete);
		throw new ProductNotFoundException(PRODUCT_IS_NOT_AVAILABLE);
	}

	@Override
	public Optional<Products> findProductById(Long id) {
		Optional<Products> products = productRepo.findById(id);
		log.info("findProductById...{}",id);
		System.out.println("A");
		System.out.println("B");
		System.out.println("C");
		if (products.isPresent())
			return products;
		throw new ProductNotFoundException(PRODUCT_IS_NOT_AVAILABLE);
	}

	@Override
	public Optional<List<Products>> findAllProducts() {
		log.info("findAllProducts...");
		System.out.println("A");
		System.out.println("B");
		System.out.println("C");
		return Optional.of(productRepo.findAll());
	}

}
