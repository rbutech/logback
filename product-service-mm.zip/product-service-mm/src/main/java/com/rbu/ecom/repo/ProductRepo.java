package com.rbu.ecom.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rbu.ecom.model.Products;

public interface ProductRepo extends JpaRepository<Products, Long> {

}
