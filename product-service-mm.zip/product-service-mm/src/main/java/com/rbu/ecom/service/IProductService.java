package com.rbu.ecom.service;

import java.util.List;
import java.util.Optional;

import com.rbu.ecom.model.Products;

public interface IProductService {
	Optional<Products> createProduct(Products product);
	Optional<Products> updateProduct(Products product);
	void deleteProduct(Long id);
	Optional<Products> findProductById(Long id);
	Optional<List<Products>> findAllProducts();
}
